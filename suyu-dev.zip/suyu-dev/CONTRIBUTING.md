<!--
SPDX-FileCopyrightText: 2018 yuzu Emulator Project
SPDX-License-Identifier: GPL-2.0-or-later
-->

Please check out the

 * [Conributors's guide](https://gitlab.com/suyu2/suyu/-/wikis/Contributing).
 * [Merge request guidelines](https://gitlab.com/suyu-emu/suyu/-/wikis/Merge-requests)
